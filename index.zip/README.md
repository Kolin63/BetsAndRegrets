# Bets and Regrets
***
You've lived a **bad** life, and now you're in the afterlife. You want a second chance, so you made a deal with the *devil*. You need to get 10 million dollars. You can get it by working for ***hundreds of years***, or you could gamble it all for a chance to win **BIG**. Luckily, you have *$5.32* from your wallet when you died. That's more than enough to gamble! And besides, most gamblers quit before they win big, so naturally, you won't quit, right? But be careful when you're gambling! If you lose too much, you'll be the devil's indentured servant...

## Rules
Every day, you can play Plinko once to try and get some money, just drop a ball or two and see where it leads you! Each ball will cost you a dollar, so use them wisely! [INSERT IMAGES WITH DESCRIPTIONS HERE]

***
## About Us

#### Ayan Bindal - The Storyteller (@3XAY)
[insert info about yourself here]

#### Colin Melican - The Programmer (@tag)
[insert info about yourself here]

#### Hayden Lee - The Artist (@tag)
[insert info about yourself vere]

#### Ayan Desai - The Audio Engineer (@tag)
[insert info about yourself here]

***
***
***
# THIS IS NOT SUPPOSED TO BE IN THIS DOC
# DIALOGUE

- Well, I guess I better make some cash. (At the start)
- What is this? Only $x? (when he wins a day, he has max souls, the earnings are between 1x and 2x)
- I guess it's something (when he wins a day, has max souls, earnings are above 2x exclusive)
- This game is rigged! (after he loses 3 times in a row, he has max souls)
- %*$@! (When he loses and no other conditions are met)
 - I won! (after he wins and no other conditions are met)
 - Finally! (after he wins and no other conditions are met)
- How am I supposed to get **10 MILLION** DOLLARS? (When he loses and no other conditions are met)
- C'mon lucky 7! (When you use 7 balls)
- No... No. NOOOOO!!! (fades out as he becomes the devil's servant, game over screen)
- Devil: You ran out of money, game's over buddy... (When you lose the soul for the 1st time)
- N-no, please give me another chance. I... I'll give you a fourth of my soul, just please, give me another chance! (When you lose your first soul)
- Devil: Alright, fine, but when your soul becomes mine, **you** become mine. Hahahaha... (After you offer your soul)
- At least I'm not back where I started... (after he loses his first soul)
- Devil: Back again? You really wanna be my servant, don't you? (When he loses his seconds soul, he snaps, screen flashes white and fades back to game as transition for all soul losses)
- I've really got to start being more careful with this... (After he loses his second soul)
- I miss my family... (After he loses a day after losing 2 souls)
- It's okay, I can get it back (After he loses a day after losing 2 souls)
- Oh! Oh yes! There is hope! (After he wins a day after losing 2 souls)
- D-do I have a chance? (After he wins a day after losing 2 souls)
- Devil: Hahahaha! You've only got one shot left, after this, you'll be mine forever. *snap* (After he loses his third soul)
- *shakey voice* N-no... I've really got to be more careful. I need to get back to my family (after he loses his third soul)
- I'm so sorry for being a liar, this is why I'm here... (when he loses a day after he lost 3 souls)
- Cheating at life landed me here... (when he loses a day after he lost 3 souls)
- *gasp* YES, YES! I HAVE A CHANCE (when he wins a day after losing 3 souls)
- I'm so close! (when he wins and is above 9M)
- I was so close! (when he loses and goes below 9M)
- Devil: Grr... You've won.. I'm a man of my word, you are free... (when you win the game)
- Yes, YES! I'm free. I'm so sorry for lying and cheating, I'll live life as a better man! I will no longer be my own worst enemy! (After he is let free)
- Narrator: After the man was let free, he lived life to the best of his ability. He became a loving husband and a caring father. He volunteered at his local soup kitchen, and was a good person overall. He had stopped lying and cheating his way through life. He was no longer, his own worst enemy. (After he wins)
- Narrator: After the man was imprisoned, his body laid lifeless. He hadn't learned his lesson about being his own worst enemy. He served the devil for the rest of eternity. (After he loses)